//
//  MusicView2.swift
//  GURUiosproject_BLANK
//
//  Created by Jake on 2022/01/30.
//

import UIKit
import YouTubePlayer

class MusicView2:UIViewController {
    
    
    @IBOutlet weak var MusicPlayer: YouTubePlayerView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let musicVideoURL2 = NSURL(string: "https://youtu.be/_ItqdBB26fQ")
        if MusicPlayer != nil {
            MusicPlayer.loadVideoURL(musicVideoURL2! as URL)
        }
    }
}
