import UIKit

class DiaryCell: UITableViewCell{

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var descLabel: UILabel!//내용은 나중에 뺴야함
    
}
