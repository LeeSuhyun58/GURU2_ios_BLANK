//
//  SettingView.swift
//  GURUiosproject_BLANK
//
//  Created by Jake on 2022/01/26.
//

import UIKit
import FMDB

class SettingView: UIViewController {
    var databasePath = String()
    var userinfo = Array<String>()
    
    @IBOutlet weak var proBtn: UIButton!
    @IBOutlet weak var chartBtn: UIButton!
    @IBOutlet weak var deleteDB: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        proBtn.layer.cornerRadius = 3
        chartBtn.layer.cornerRadius = 3
        deleteDB.layer.cornerRadius = 3
    }
    
    @IBAction func BLANK(_ sender: Any) {
        //팝업창
        let alert = UIAlertController(title: "BLANK 탈퇴", message: "정말 탈퇴하시겠습니까?", preferredStyle: .alert)
        
        let ok = UIAlertAction(title: "확인", style: .default) { (ok) in
            //탈퇴하는 경우 데베에서 정보 삭제
            let dirPaths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
            let docDir = dirPaths[0]
            self.databasePath = docDir + "/userinfo.db"
            let db=FMDatabase(path:self.databasePath)
            if db.open(){
                db.executeStatements("delete from userinfo")
            }
            
            //홈화면으로 이동
            //스토리보드 보기1
            let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
            //(화면에 보일)홈화면 스토리보드
            let settingboard = storyboard.instantiateViewController(withIdentifier: "Login")
            //설정한 뷰 컨트롤러 보여주기 -> present
            settingboard.modalPresentationStyle = .fullScreen
            self.present(settingboard,animated: true,completion: nil)
        }
        
        let cancle = UIAlertAction(title: "취소", style: .default) { (cancle) in
            //이동할 필요 X
        }
        
        //ok를 선택한 경우
        alert.addAction(ok)
        //cancle을 사용하는 경우
        alert.addAction(cancle)
        
        self.present(alert, animated: true, completion: nil)
    }
}
