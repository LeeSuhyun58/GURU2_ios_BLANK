//
//  LoginViewController.swift
//  GURUiosproject_BLANK
//
//  Created by Jake on 2022/02/01.
//

import UIKit
import FMDB

class LoginViewController:UIViewController {
    var databasePath = String()
    var userinfo = Array<String>()
    
    @IBOutlet weak var ReCheckName: UITextField!
    @IBOutlet weak var GoHomeBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //디비 열기 함수
        self.openDB()
        //버튼 모서리 둥글게
        GoHomeBtn.layer.cornerRadius = 5
    }
    
    //디비 파일 열기
    func openDB(){
        let fileMgr = FileManager.default
        let dirPaths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let docDir = dirPaths[0]
        
        databasePath = docDir + "/userinfo.db"
        if !fileMgr.fileExists(atPath: databasePath){
            let db = FMDatabase(path: databasePath)
            if db.open() {
                
            }
        } else{
            NSLog("디비파일 열기 성공")
        }
    }
    
    @IBAction func LoginCheck(_ sender: Any) {
        let db = FMDatabase(path: databasePath)
        if db.open(){
            let query = "select name from userinfo"
            if let result = db.executeQuery(query, withArgumentsIn: []){
                if result.next() {
                    NSLog("데이터 확인 성공")
                    //var columnArray = Array<String>()
                    
                    if result.string(forColumn: "name") == ReCheckName.text!{
                        let alert = UIAlertController(title: "로그인 성공", message: "BLANK에서 회원님의 정보를 확인했어요!", preferredStyle: .alert)
                        
                        let ok = UIAlertAction(title: "확인", style: .default) { (ok) in
                            //홈화면으로 이동
                            //스토리보드 보기1
                            let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
                            //(화면에 보일)홈화면 스토리보드
                            let settingboard = storyboard.instantiateViewController(withIdentifier: "Main")
                            //설정한 뷰 컨트롤러 보여주기 -> present
                            settingboard.modalPresentationStyle = .fullScreen
                            self.present(settingboard,animated: true,completion: nil)
                        }
                        //ok를 선택한 경우
                        alert.addAction(ok)
                        
                        self.present(alert, animated: true, completion: nil)
                    } else {
                    //팝업창
                    let alert = UIAlertController(title: "로그인 실패", message: "회원님의 정보를 확인할 수 없어요!", preferredStyle: .alert)
                    
                    let ok = UIAlertAction(title: "확인", style: .default) { (ok) in
                        //홈화면으로 이동
                        //스토리보드 보기1
                        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
                        //(화면에 보일)홈화면 스토리보드
                        let settingboard = storyboard.instantiateViewController(withIdentifier: "Login")
                        //설정한 뷰 컨트롤러 보여주기 -> present
                        settingboard.modalPresentationStyle = .fullScreen
                        self.present(settingboard,animated: true,completion: nil)
                    }
                    //ok를 선택한 경우
                    alert.addAction(ok)
                    
                    self.present(alert, animated: true, completion: nil)
                }
                } else {
                NSLog("데이터 확인 실패")
                }
            }
        }
    }
    //키보드 제스쳐
    @IBAction func LoginGesture(_ sender: Any) {
        view.endEditing(true)
    }
}
