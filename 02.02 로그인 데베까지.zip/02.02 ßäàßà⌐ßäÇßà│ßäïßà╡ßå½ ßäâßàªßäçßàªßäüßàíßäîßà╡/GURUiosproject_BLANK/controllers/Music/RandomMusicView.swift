//
//  RandomMusicView.swift
//  GURUiosproject_BLANK
//
//  Created by Jake on 2022/01/30.
//

import UIKit
import YouTubePlayer

class RandomMusicView:UIViewController{
    @IBAction func goMain(_ sender: Any) {
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        //(화면에 보일)홈화면 스토리보드
        let settingboard = storyboard.instantiateViewController(withIdentifier: "Main")
        //설정한 뷰 컨트롤러 보여주기 -> present
        settingboard.modalPresentationStyle = .fullScreen
        self.present(settingboard,animated: true,completion: nil)
    }
    

    
    @IBOutlet weak var RandomMusicPlayer: YouTubePlayerView!
    
   
    override func viewDidLoad() {
        let randomMusic: UInt32 = arc4random_uniform(7)
        switch randomMusic {
        case 0:
            let musicVideoURL = NSURL(string: "https://youtu.be/4iFP_wd6QU8")
            if RandomMusicPlayer != nil {
                RandomMusicPlayer.loadVideoURL(musicVideoURL! as URL)}
        case 1:
                let musicVideoURL = NSURL(string: "https://youtu.be/v3SaQZypZ_U")
                if RandomMusicPlayer != nil {
                    RandomMusicPlayer.loadVideoURL(musicVideoURL! as URL)}
        case 2:
            let musicVideoURL = NSURL(string: "https://youtu.be/_ItqdBB26fQ")
            if RandomMusicPlayer != nil {
                RandomMusicPlayer.loadVideoURL(musicVideoURL! as URL)}
        case 3:
            let musicVideoURL = NSURL(string: "https://youtu.be/1HCMC9eKzG0")
            if RandomMusicPlayer != nil {
                RandomMusicPlayer.loadVideoURL(musicVideoURL! as URL)
            }
        case 4:
            let musicVideoURL = NSURL(string: "https://www.youtube.com/watch?v=iQWBGD0YP5A")
            if RandomMusicPlayer != nil {
                RandomMusicPlayer.loadVideoURL(musicVideoURL! as URL)
            }
        default:
            let musicVideoURL = NSURL(string: "https://youtu.be/dboaFYdUxFs")
            if RandomMusicPlayer != nil {
                RandomMusicPlayer.loadVideoURL(musicVideoURL! as URL)
            }
        }
    }
}

