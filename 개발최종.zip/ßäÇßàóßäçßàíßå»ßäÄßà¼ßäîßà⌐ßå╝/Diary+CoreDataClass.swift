//
//  Diary+CoreDataClass.swift
//  
//
//  Created by Jake on 2022/02/04.
//
//

import Foundation
import CoreData

@objc(Diary)
public class Diary: NSManagedObject {

}
