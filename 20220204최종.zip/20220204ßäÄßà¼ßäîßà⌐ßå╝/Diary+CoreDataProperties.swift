//
//  Diary+CoreDataProperties.swift
//  
//
//  Created by Jake on 2022/02/04.
//
//

import Foundation
import CoreData


extension Diary {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Diary> {
        return NSFetchRequest<Diary>(entityName: "Diary")
    }

    @NSManaged public var date: String?
    @NSManaged public var deletedDate: Date?
    @NSManaged public var desc: String?
    @NSManaged public var id: Int32
    @NSManaged public var title: String?
    @NSManaged public var imageView: Data?

}
