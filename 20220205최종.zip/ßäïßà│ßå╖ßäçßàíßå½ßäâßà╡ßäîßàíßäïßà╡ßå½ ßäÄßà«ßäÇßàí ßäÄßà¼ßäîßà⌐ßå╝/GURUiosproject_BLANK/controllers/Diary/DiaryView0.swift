//
//  DiaryView0.swift
//  GURUiosproject_BLANK
//
//  Created by Jake on 2022/01/30.
//

import UIKit
import CoreData

class DiaryView0:UIViewController, UITextFieldDelegate, UITextViewDelegate {
    var date:String!
    var EmotionImage:UIImage!
    
    @IBOutlet weak var DiaryEmotion: UIImageView!
    @IBOutlet weak var subBtn: UIButton!
    @IBOutlet weak var DiaryLabel: UILabel!
    
    //제목
    @IBOutlet weak var titleTF: UITextField!
    //내용
    @IBOutlet weak var descTV: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //버튼 비활성화
        self.DiaryLabel.text = date
        self.DiaryEmotion.image = EmotionImage
        
        //일기 저장 버튼 둥글게 커스텀
        descTV.layer.cornerRadius = 10
        subBtn.layer.cornerRadius = 5
        
        //버튼 비활성화
        //self.DiaryTextField.delegate = self
        self.descTV.delegate = self
    }
    
    func textViewTap(_textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
            if text == "\n" {
                if range.location == 0 && range.length != 0 {
                    self.subBtn.isEnabled = false
                } else {
                    self.subBtn.isEnabled = true
                }
            }
            return true
        }
    
    //save도 같이 해야 함 => saveAction
    @IBAction func DiaryCheck(_ sender: UIButton) {//원래 UIButton
        let selectedDiary: Diary? = nil
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context: NSManagedObjectContext = appDelegate.persistentContainer.viewContext
        if(selectedDiary == nil){
            let entity = NSEntityDescription.entity(forEntityName: "Diary", in: context)
            let newDiary = Diary(entity: entity!, insertInto: context)
            newDiary.id = DiaryList.count as NSNumber
            newDiary.title = self.titleTF.text
            newDiary.desc = self.descTV.text
            newDiary.date = self.DiaryLabel.text
            let png = self.DiaryEmotion.image?.pngData()
            newDiary.image = png
            do{
                try context.save()
                DiaryList.append(newDiary)
            }
            catch{
                print("context save error")
            }
        }
        //지금 듣기 / 나중에 듣기  선택
        let alert = UIAlertController(title: "BLANK", message: "오늘의 BLANK를 채울 노래가 추천되었어요. 지금 들어보시는거 어떠세요?", preferredStyle: .alert)
        
        let ok = UIAlertAction(title: "지금 듣기", style: .default)
        { (ok) in
            let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
            let settingboard = storyboard.instantiateViewController(withIdentifier: "RM")
            self.navigationController?.pushViewController(settingboard, animated: true)
        }
        
        //나중에 듣기
        let cancel = UIAlertAction(title: "나중에 듣기", style: .default)
        { (cancel) in
            self.navigationController?.popToRootViewController(animated: true)
            /*
            //스토리보드 보기
            let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
            //(화면에 보일)홈화면 스토리보드
            let settingboard = storyboard.instantiateViewController(withIdentifier: "Main")
            //설정한 뷰 컨트롤러 보여주기 -> present
            settingboard.modalPresentationStyle = .fullScreen
            self.present(settingboard,animated: true,completion: nil)*/
        }
        alert.addAction(cancel)
        
        alert.addAction(ok)
        
        self.present(alert, animated: true, completion: nil)
        //return
    }
    
    //키보드 제스쳐
    @IBAction func TapGesture(_ sender: Any) {
        view.endEditing(true)
    }
}
