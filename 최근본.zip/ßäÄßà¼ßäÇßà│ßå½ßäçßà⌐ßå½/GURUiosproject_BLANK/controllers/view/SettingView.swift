//
//  SettingView.swift
//  GURUiosproject_BLANK
//
//  Created by Jake on 2022/01/26.
//

import UIKit
import FMDB
//import CoreData

class SettingView: UIViewController {
    var databasePath = String()
    var userinfo = Array<String>()
    
    @IBOutlet weak var proBtn: UIButton!
    @IBOutlet weak var chartBtn: UIButton!
    @IBOutlet weak var deleteDB: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //디비 열기 함수
        self.openDB()
        
        proBtn.layer.cornerRadius = 5
        chartBtn.layer.cornerRadius = 5
        deleteDB.layer.cornerRadius = 5
    }
    
    //디비 파일 열기
    func openDB(){
        let fileMgr = FileManager.default
        let dirPaths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let docDir = dirPaths[0]
        
        databasePath = docDir + "/userinfo.db"
        if !fileMgr.fileExists(atPath: databasePath){
            let db = FMDatabase(path: databasePath)
            if db.open() {
                NSLog("파일이 존재하지 않는 경우 디비 생성")
            }
        } else{
            NSLog("디비파일 열기 성공")
        }
    }
    
    @IBAction func BLANK(_ sender: Any) {
        //팝업창
        let alert = UIAlertController(title: "BLANK 탈퇴", message: "정말 탈퇴하시겠습니까?", preferredStyle: .alert)
        
        let ok = UIAlertAction(title: "확인", style: .destructive) { (ok) in
            //탈퇴하는 경우 데베에서 정보 삭제
            let dirPaths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
            let docDir = dirPaths[0]
            self.databasePath = docDir + "/userinfo.db"
            let db=FMDatabase(path:self.databasePath)
            if db.open(){
                db.executeStatements("delete from userinfo")
                //앱종료
                //exit(0)
                //coredata 삭제 필요
                
            }
            //일기 전체 삭제
            /*let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
            context.delete(item)
            do{
                try context.save()
            }
            catch{
                print("error")
            }*/
            
            //홈화면으로 이동
            //스토리보드 보기1
            let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
            //(화면에 보일)홈화면 스토리보드
            let settingboard = storyboard.instantiateViewController(withIdentifier: "Login")
            //설정한 뷰 컨트롤러 보여주기 -> present
            settingboard.modalPresentationStyle = .fullScreen
            self.present(settingboard,animated: true,completion: nil)
        }
        
        let cancle = UIAlertAction(title: "취소", style: .default)
        
        //ok를 선택한 경우
        alert.addAction(ok)
        //cancle을 사용하는 경우
        alert.addAction(cancle)
        
        self.present(alert, animated: true, completion: nil)
    }
}
