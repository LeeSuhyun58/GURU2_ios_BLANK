//
//  MusicView.swift
//  GURUiosproject_BLANK
//
//  Created by Jake on 2022/01/30.
//

import UIKit
import YouTubePlayer

class MusicView: UIViewController{
    
    
    @IBOutlet weak var videoPlayer: YouTubePlayerView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let musicVideoURL = NSURL(string: "https://youtu.be/4iFP_wd6QU8")
        if videoPlayer != nil {
            videoPlayer.loadVideoURL(musicVideoURL! as URL)
        }
    }
    
}
