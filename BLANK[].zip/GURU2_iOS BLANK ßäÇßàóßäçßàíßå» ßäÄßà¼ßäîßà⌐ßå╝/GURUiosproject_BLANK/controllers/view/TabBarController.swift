//
//  TabBarController.swift
//  GURUiosproject_BLANK
//
//  Created by swuad_21 on 2022/01/21.
//

import UIKit

class TabBarController:UITabBarController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.selectedIndex = 0 //TabBar 시작 순서를 홈(Home)으로 설정
        
    }
}
