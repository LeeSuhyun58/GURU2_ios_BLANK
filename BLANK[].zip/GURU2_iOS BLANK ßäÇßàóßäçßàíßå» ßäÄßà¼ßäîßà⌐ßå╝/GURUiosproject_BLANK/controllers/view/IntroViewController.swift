//
//  IntroViewController.swift
//  GURUiosproject_BLANK
//
//  Created by Jake on 2022/02/06.
//

import UIKit
import SwiftyGif

class IntroViewController: UIViewController {
    
    @IBOutlet weak var IntroImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        do {
            let gif = try UIImage(gifName: "런치화면.gif")
            self.IntroImage.setGifImage(gif, loopCount: 1)
            //self.IntroImage.delegate = self
        } catch {
            NSLog("재생불가능")
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        let timer = Timer.scheduledTimer(withTimeInterval: 5, repeats: false) { timer in
            if let vc = self.storyboard?.instantiateViewController(withIdentifier: "Login"){
                vc.modalPresentationStyle = .fullScreen
                self.present(vc, animated: true, completion: nil)
            }
        }
    }
   
}

