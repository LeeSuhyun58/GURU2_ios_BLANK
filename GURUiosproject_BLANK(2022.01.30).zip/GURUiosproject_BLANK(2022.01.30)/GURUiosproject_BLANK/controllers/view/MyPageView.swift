//
//  MyPageView.swift
//  GURUiosproject_BLANK
//
//  Created by Jake on 2022/01/26.
//

import UIKit

class MyPageView:UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
}
