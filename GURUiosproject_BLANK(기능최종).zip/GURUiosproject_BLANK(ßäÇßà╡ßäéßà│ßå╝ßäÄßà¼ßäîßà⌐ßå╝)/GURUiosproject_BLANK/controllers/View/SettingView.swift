//
//  SettingView.swift
//  GURUiosproject_BLANK
//
//  Created by Jake on 2022/01/26.
//

import UIKit

class SettingView: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
