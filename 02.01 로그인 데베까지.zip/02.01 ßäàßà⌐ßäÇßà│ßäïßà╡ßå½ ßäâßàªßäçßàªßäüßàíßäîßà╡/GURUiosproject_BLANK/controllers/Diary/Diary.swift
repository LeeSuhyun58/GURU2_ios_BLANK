import CoreData


@objc(Diary)
class Diary: NSManagedObject
{
    @NSManaged var id: NSNumber!
    @NSManaged var title: String!
    @NSManaged var desc: String!
    @NSManaged var deletedDate: Date? //나중에 뺴자
}
